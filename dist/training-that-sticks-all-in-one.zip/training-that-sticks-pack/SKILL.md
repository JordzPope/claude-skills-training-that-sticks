---
name: training-that-sticks-pack
description: "Drafts and checks the documents L&D leaders write, 24 in all: Performance Gap Brief, On-the-Job Objectives, Learning Impact Map, Transfer Risk Audit, Manager Pre-Course Brief, Course Joining Note, Sponsor Message, Real Work Brief, Retrieval Practice Set, Practice Scenarios, Session Plan Rework, Transfer Action Plan, Spaced Follow-Up Plan, Reinforcement Nudges, Job Aid, Practice Challenges, Manager Follow-Up Guide, Observation Guide, Peer Practice Circle, Barrier Removal Plan, Transfer Evaluation Plan, Application Survey, Success Case Interviews, Learning Impact Report. Use when L&D leaders ask for any of these, or for help to start from the job, set it up before day one, build in the practice, space it out, back it at work, prove it stuck."
---

# Training that sticks

All 24 skills from pack 02 in one upload. Each skill's full instructions are in `skills/<slug>/INSTRUCTIONS.md`, with its sample input in that folder's `examples/`.

## How to use this bundle

1. Match the request to one skill in the table. If two fit, ask the user which they mean.
2. Read that skill's INSTRUCTIONS.md in full and follow it exactly. Paths inside it (`examples/...`, `templates/...`) are relative to that skill's own folder.
3. If nothing matches, say which skills come closest and what each produces.

## Skills

| # | Skill | Use it for | Instructions |
| --- | --- | --- | --- |
| 01 | Performance Gap Brief | Turns a training request into the behaviour, the gap and its cause before a course is booked. | `skills/performance-gap-brief/INSTRUCTIONS.md` |
| 02 | On-the-Job Objectives | Rewrites course objectives as behaviours someone could watch happen at work. | `skills/on-the-job-objectives/INSTRUCTIONS.md` |
| 03 | Learning Impact Map | Links each skill to a behaviour, a team result and a business goal on one page. | `skills/learning-impact-map/INSTRUCTIONS.md` |
| 04 | Transfer Risk Audit | Checks a planned programme against what predicts transfer, and names the weak spots. | `skills/transfer-risk-audit/INSTRUCTIONS.md` |
| 05 | Manager Pre-Course Brief | The talk a manager has with each learner before the course: why, what to try, when to review. | `skills/manager-pre-course-brief/INSTRUCTIONS.md` |
| 06 | Course Joining Note | Joining instructions that set the expectation of using it at work, with the logistics. | `skills/course-joining-note/INSTRUCTIONS.md` |
| 07 | Sponsor Message | A short note from a senior leader on why this matters and what should change. | `skills/sponsor-message/INSTRUCTIONS.md` |
| 08 | Real Work Brief | Asks each learner to bring one live task to the course, with a template to fill in. | `skills/real-work-brief/INSTRUCTIONS.md` |
| 09 | Retrieval Practice Set | Questions that make people recall and apply, set for the course and the weeks after. | `skills/retrieval-practice-set/INSTRUCTIONS.md` |
| 10 | Practice Scenarios | Work scenarios with decision points and feedback, at three levels of difficulty. | `skills/practice-scenarios/INSTRUCTIONS.md` |
| 11 | Session Plan Rework | Checks a session plan for practice time and real-work links, then rewrites the weak parts. | `skills/session-plan-rework/INSTRUCTIONS.md` |
| 12 | Transfer Action Plan | If-then plans for when, where and how each learner will first use the skill. | `skills/transfer-action-plan/INSTRUCTIONS.md` |
| 13 | Spaced Follow-Up Plan | A dated schedule of recall and practice touchpoints for the 8 to 12 weeks after a course. | `skills/spaced-follow-up-plan/INSTRUCTIONS.md` |
| 14 | Reinforcement Nudges | The emails or Teams messages for each touchpoint, each asking for one thing at work. | `skills/reinforcement-nudges/INSTRUCTIONS.md` |
| 15 | Job Aid | A one-page checklist or decision guide people use at the moment they need it. | `skills/job-aid/INSTRUCTIONS.md` |
| 16 | Practice Challenges | Short weekly challenges that get the skill used on real work in the first month. | `skills/practice-challenges/INSTRUCTIONS.md` |
| 17 | Manager Follow-Up Guide | The questions a manager asks at day 7, 30 and 60, built on the GROW model. | `skills/manager-follow-up-guide/INSTRUCTIONS.md` |
| 18 | Observation Guide | What good looks like on the job, for a manager to watch for and give feedback on. | `skills/observation-guide/INSTRUCTIONS.md` |
| 19 | Peer Practice Circle | Agenda and prompts for a small group that meets to share what they tried and what stuck. | `skills/peer-practice-circle/INSTRUCTIONS.md` |
| 20 | Barrier Removal Plan | Finds what stops people using it at work, from time to targets, and who can fix each. | `skills/barrier-removal-plan/INSTRUCTIONS.md` |
| 21 | Transfer Evaluation Plan | What you'll measure, when and from which source, mapped to LTEM tiers or Kirkpatrick levels. | `skills/transfer-evaluation-plan/INSTRUCTIONS.md` |
| 22 | Application Survey | A 60-day survey on what people used, what got in the way and what changed. | `skills/application-survey/INSTRUCTIONS.md` |
| 23 | Success Case Interviews | Find who used it, what it changed and why others didn't, using Brinkerhoff's method. | `skills/success-case-interviews/INSTRUCTIONS.md` |
| 24 | Learning Impact Report | A report for leaders on behaviour change and results, with the strength of evidence shown. | `skills/learning-impact-report/INSTRUCTIONS.md` |

## The one rule

Claude drafts the plans, nudges and reports. Managers do the coaching, and a person makes every call about someone's skill.
